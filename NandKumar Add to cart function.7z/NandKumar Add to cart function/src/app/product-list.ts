import {Product} from './product';

export const PRODUCTS: Product[] = [
  { productId: 11, productName: 'Product 1', productPrice: 12000, productImg: "../assets/img1.jpg" },
  { productId: 12, productName: 'Product 2', productPrice: 13000, productImg: "../assets/img2.jpg" },
  { productId: 13, productName: 'Product 3', productPrice: 14000, productImg: "../assets/img3.jpg" },
  { productId: 14, productName: 'Product 4', productPrice: 15000, productImg: "../assets/img4.jpg" },
  { productId: 15, productName: 'Product 5', productPrice: 16000, productImg: "../assets/img4.jpg" },
  { productId: 16, productName: 'Product 6', productPrice: 16000, productImg: "../assets/img4.jpg" },
  { productId: 17, productName: 'Product 7', productPrice: 16000, productImg: "../assets/img4.jpg" },
  { productId: 18, productName: 'Product 8', productPrice: 16000, productImg: "../assets/img4.jpg" },
];