export class Product{
    productId: number;
    productName: string;
    productPrice: number;
    productImg: string;
}