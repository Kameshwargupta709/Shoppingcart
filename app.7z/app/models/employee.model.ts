export class Employee{
    id:number;
    name:string;
    type:string;
    email:string;
    phonenumber:string;
    contactPreference:string;
    dateOfBirth:Date;
    department:string;
    isActive:boolean;
    photoPath:string;
}